//
//  ImmersiveView.swift
//  Circle2Search
//
//  Created by LightningLion on 2025/1/28.
//

import SwiftUI
import RealityKit
import RealityKitContent
import MixedRealityKit
import os
import UIKit

// 新增：保存CGImage到本地Documents目录
func saveCGImageToDisk(_ image: CGImage) {
    let uiImage = UIImage(cgImage: image)
    if let data = uiImage.pngData() {
        let fileManager = FileManager.default
        let folderURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first!
        let fileName = "circle_shot_\(Date().timeIntervalSince1970).png"
        let fileURL = folderURL.appendingPathComponent(fileName)
        do {
            try data.write(to: fileURL)
            os_log("图片已保存到：%@", fileURL.path)
        } catch {
            os_log("保存图片失败：%@", error.localizedDescription)
        }
    }
}

// 分享面板
struct ShareSheet: UIViewControllerRepresentable {
    var activityItems: [Any]
    var applicationActivities: [UIActivity]? = nil

    func makeUIViewController(context: Context) -> UIActivityViewController {
        let controller = UIActivityViewController(activityItems: activityItems, applicationActivities: applicationActivities)
        return controller
    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

struct ImmersiveView: View {
    var circleManager:CircleManager
    @State
    private var vm = ImmersiveViewModel()
    @State
    private var drawingController: DrawingController?
    @State
    private var shareImage: UIImage? = nil
    @State
    private var detectionResults: [(String, Float, String)] = []
    var body: some View {
        CameraPassthroughMR(attachments:$vm.attachments, liveFrame: $vm.liveFrame) { content in
            vm.content = content
            vm.contentPack = RealityViewContentPack(realityViewContent: content)
        }
        .modifier(EnableSparkleBrush(circleManager: circleManager, drawingController: $drawingController, contentPack: $vm.contentPack))
        .modifier(ChangeColorOvertime(mod: $drawingController))
        .modifier(ShowCircledImage(liveFrame: vm.liveFrame, circleManager: circleManager,addImage: { imageData, searchPanelData in
            vm.addImage(imageData: imageData, searchPanelData: searchPanelData, shareImageSetter: { img in
                self.shareImage = img
            }, onDetectionResult: { label, confidence, explanation in
                self.detectionResults.append((label, confidence, explanation))
            })
        }))
        .sheet(item: $shareImage) { image in
            ShareSheet(activityItems: [image])
        }
        .overlay(alignment: .bottom) {
            VStack {
                ForEach(detectionResults, id: \.0) { result in
                    DetectionResultView(label: result.0, confidence: result.1, explanation: result.2)
                }
            }
            .padding()
        }
    }
}

struct DetectionResultView: View {
    let label: String
    let confidence: Float
    let explanation: String
    
    var body: some View {
        VStack {
            Text("检测到：\(label)")
            Text("置信度：\(String(format: "%.2f", confidence * 100))%")
            Text("解释：\(explanation)")
        }
        .padding()
        .background(Color.blue.opacity(0.1))
        .cornerRadius(10)
    }
}

@MainActor
@Observable
fileprivate
class ImmersiveViewModel {
    var liveFrame: FrameData?
    var cameraImage:CGImage? {
        liveFrame?.cameraPhoto
    }
    var mrData:MRData? {
        liveFrame?.mrData
    }
    var content:RealityViewContent? = nil
    var contentPack:RealityViewContentPack? = nil
    var attachments:[AttachmentComponent] = []
    // 存储已添加到场景中的实体(图像、搜索结果面板)
    var circleRepresentatives:[Entity] = []
    private let detector = YOLODetector() // 初始化YOLO检测器
    func addImage(imageData:CircledImageData,searchPanelData:SearchPanelData, shareImageSetter: ((UIImage) -> Void)? = nil, onDetectionResult: ((String, Float, String) -> Void)? = nil) {
        do {
            if let lastItem = circleRepresentatives.last,let lastIndex = circleRepresentatives.lastIndex(of: lastItem) {
                circleRepresentatives.remove(at: lastIndex)
                fadeOut(for: lastItem)
            }
            let representativeEntity = try addImageInner(imageData:imageData, shareImageSetter: shareImageSetter, onDetectionResult: onDetectionResult)
            self.circleRepresentatives.append(representativeEntity)
        } catch {
            os_log("\(error.localizedDescription)")
        }
    }
    private
    func fadeOut(for entity:Entity) {
         let opacityAction = FromToByAction<Float>(to: 0.0,
                                                   timing: .easeInOut,
                                                   isAdditive: false)
        do {
            let opacityAnimation = try AnimationResource
                .makeActionAnimation(for: opacityAction,
                                     duration: 0.3,
                                     bindTarget: .opacity)
           
            entity.playAnimation(opacityAnimation)
        } catch {
            os_log("\(error.localizedDescription)")
        }
    }
    private
    func addImageInner(imageData:CircledImageData, shareImageSetter: ((UIImage) -> Void)? = nil, onDetectionResult: ((String, Float, String) -> Void)? = nil) throws -> Entity {
        guard let content else {
            os_log("RealityViewContent没有准备好")
            throw AddImageError.realitySceneNotReady
        }
        let oneCircleEntity = Entity()
        content.add(oneCircleEntity)
        let imageEntity = Entity()
        oneCircleEntity.addChild(imageEntity, preservingWorldTransform: true)
        imageEntity.components.set(attachments.queryNewItem(attachmentView: AnyView(CircledImageView(size: .init(width: imageData.size.0, height: imageData.size.1), image: imageData.croppedImage))))
        imageEntity.setTransformMatrix(imageData.transform.matrix, relativeTo: nil)
        // 保存图片到本地Documents目录
        saveCGImageToDisk(imageData.croppedImage)
        // 设置YOLO检测回调
        detector.onDetectionResult = onDetectionResult
        // 调用YOLO识别
        detector.detectObjects(in: imageData.croppedImage)
        // 弹出分享面板
        let uiImage = UIImage(cgImage: imageData.croppedImage)
        shareImageSetter?(uiImage)
        return oneCircleEntity
    }
    enum AddImageError:Error,LocalizedError {
        case realitySceneNotReady
        var errorDescription: String? {
            switch self {
            case .realitySceneNotReady:
                "RealitySceneNotReady"
            }
        }
    }
}
