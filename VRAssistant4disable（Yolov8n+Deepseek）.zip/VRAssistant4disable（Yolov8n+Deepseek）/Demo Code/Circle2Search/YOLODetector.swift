import Vision
import CoreML
import UIKit

class YOLODetector {
    private var detectionRequest: VNCoreMLRequest?
    private let modelURL = Bundle.main.url(forResource: "yolov8n", withExtension: "mlmodelc")!
    var onDetectionResult: ((String, Float, String) -> Void)?
    
    init() {
        setupModel()
    }
    
    private func setupModel() {
        guard let model = try? MLModel(contentsOf: modelURL),
              let visionModel = try? VNCoreMLModel(for: model) else {
            print("模型加载失败")
            return
        }
        detectionRequest = VNCoreMLRequest(model: visionModel) { request, error in
            if let error = error {
                print("识别失败：\(error.localizedDescription)")
                return
            }
            guard let results = request.results as? [VNRecognizedObjectObservation] else { return }
            self.processResults(results)
        }
        detectionRequest?.imageCropAndScaleOption = .scaleFit
    }
    
    private func processResults(_ results: [VNRecognizedObjectObservation]) {
        for observation in results {
            let topLabelObservation = observation.labels.first!
            let boundingBox = observation.boundingBox
            let confidence = topLabelObservation.confidence
            let label = topLabelObservation.identifier
            print("检测到：\(label), 置信度：\(confidence), 位置：\(boundingBox)")
            let explanation = generateExplanation(label: label, confidence: confidence)
            print("解释：\(explanation)")
            onDetectionResult?(label, confidence, explanation)
        }
    }
    
    private func generateExplanation(label: String, confidence: Float) -> String {
        return "检测到\(label)，置信度为\(String(format: "%.2f", confidence * 100))%。"
    }
    
    func detectObjects(in image: CGImage) {
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self = self, let request = self.detectionRequest else { return }
            let handler = VNImageRequestHandler(cgImage: image, options: [:])
            try? handler.perform([request])
        }
    }
} 